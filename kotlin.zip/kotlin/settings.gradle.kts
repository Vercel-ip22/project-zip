rootProject.name = "sum-amounts"
