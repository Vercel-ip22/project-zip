package sumamounts

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class SumAmountsTest {
    private fun ob(id: Long, amountDue: Long, priority: Long) = Obligation(id, amountDue, priority)

    private fun assertSettlement(
        payment: Long,
        obligations: List<Obligation>,
        unapplied: Long,
        vararg lines: Line,
    ) {
        assertEquals(Settlement(lines.toList(), unapplied), settle(payment, obligations))
    }

    @Test
    fun empty() {
        assertSettlement(100, emptyList(), 100)
    }

    @Test
    fun paysInFull() {
        assertSettlement(
            500,
            listOf(ob(1, 100, 1), ob(2, 40, 3), ob(3, 60, 2)),
            300,
            Line(1, 100),
            Line(2, 40),
            Line(3, 60),
        )
    }

    @Test
    fun higherPriorityIsPaidFirst() {
        assertSettlement(
            60,
            listOf(ob(1, 80, 1), ob(2, 50, 9), ob(3, 25, 9)),
            0,
            Line(1, 0),
            Line(2, 50),
            Line(3, 10),
        )
    }

    @Test
    fun samePriorityPaysEarlierInputFirst() {
        assertSettlement(
            10,
            listOf(ob(1, 50, 1), ob(2, 30, 1), ob(3, 20, 1)),
            0,
            Line(1, 10),
            Line(2, 0),
            Line(3, 0),
        )
    }

    @Test
    fun remainderSpillsToTheNextPriority() {
        assertSettlement(
            120,
            listOf(ob(1, 100, 1), ob(2, 40, 5), ob(3, 60, 5)),
            0,
            Line(1, 20),
            Line(2, 40),
            Line(3, 60),
        )
    }

    @Test
    fun duplicateId() {
        assertFailsWith<IllegalArgumentException> {
            settle(5, listOf(ob(1, 10, 1), ob(1, 4, 2)))
        }
    }
}
