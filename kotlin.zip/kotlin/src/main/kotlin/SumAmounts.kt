package sumamounts

data class Obligation(val id: Long, val amountDue: Long, val priority: Long)

data class Line(val id: Long, val applied: Long)

data class Settlement(val lines: List<Line>, val unapplied: Long)

fun settle(payment: Long, obligations: List<Obligation>): Settlement {
    throw UnsupportedOperationException("not implemented")
}
