# Settle a payment (Kotlin)

Implement `settle` in `src/main/kotlin/SumAmounts.kt`. Plan on 15 minutes. The rules are in [SPEC.md](SPEC.md).

Do not change `src/test/kotlin/SumAmountsTest.kt`.

## Run

From this directory:

```bash
gradle test
```

## Submit

This directory is only the Kotlin task. Create a branch and push it. Do not change `src/test/`, `SPEC.md`, or `.github/`.

From this directory:

```bash
git checkout -b candidate/<your-name>
git add src/main/kotlin/SumAmounts.kt
git commit -m "Implement settlement"
git push -u origin candidate/<your-name>
```
