# Settle a payment (Move)

Implement `settle` in `sources/amounts.move`. Plan on 15 minutes. The rules are in [SPEC.md](SPEC.md).

Do not change `tests/amounts_tests.move`.

## Run

From this directory:

```bash
aptos move test
```

## Submit

This directory is only the Move task. Create a branch and push it. Do not change `tests/`, `SPEC.md`, or `.github/`.

From this directory:

```bash
git checkout -b candidate/<your-name>
git add sources/amounts.move
git commit -m "Implement settlement"
git push -u origin candidate/<your-name>
```
