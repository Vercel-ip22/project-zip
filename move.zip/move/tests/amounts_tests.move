#[test_only]
module sum_amounts::amounts_tests {
    use std::vector;
    use sum_amounts::amounts::{Self, Obligation, Settlement};

    fun ob(id: u64, amount_due: u64, priority: u64): Obligation {
        Obligation { id, amount_due, priority }
    }

    fun check(payment: u64, obligations: vector<Obligation>, applied: vector<u64>, unapplied: u64) {
        let ids = vector<u64>[];
        let i = 0;
        while (i < vector::length(&obligations)) {
            vector::push_back(&mut ids, vector::borrow(&obligations, i).id);
            i = i + 1;
        };
        let got: Settlement = amounts::settle(payment, obligations);
        assert!(got.unapplied == unapplied, 100);
        assert!(vector::length(&got.lines) == vector::length(&applied), 101);
        i = 0;
        while (i < vector::length(&applied)) {
            let line = vector::borrow(&got.lines, i);
            assert!(line.id == *vector::borrow(&ids, i), 102);
            assert!(line.applied == *vector::borrow(&applied, i), 103);
            i = i + 1;
        };
    }

    #[test]
    fun test_empty() {
        check(100, vector[], vector[], 100);
    }

    #[test]
    fun test_pays_in_full() {
        check(
            500,
            vector[ob(1, 100, 1), ob(2, 40, 3), ob(3, 60, 2)],
            vector[100, 40, 60],
            300,
        );
    }

    #[test]
    fun test_higher_priority_is_paid_first() {
        check(60, vector[ob(1, 80, 1), ob(2, 50, 9), ob(3, 25, 9)], vector[0, 50, 10], 0);
    }

    #[test]
    fun test_same_priority_pays_earlier_input_first() {
        check(10, vector[ob(1, 50, 1), ob(2, 30, 1), ob(3, 20, 1)], vector[10, 0, 0], 0);
    }

    #[test]
    fun test_remainder_spills_to_the_next_priority() {
        check(120, vector[ob(1, 100, 1), ob(2, 40, 5), ob(3, 60, 5)], vector[20, 40, 60], 0);
    }

    #[test]
    #[expected_failure(abort_code = 2, location = sum_amounts::amounts)]
    fun test_duplicate_id() {
        amounts::settle(5, vector[ob(1, 10, 1), ob(1, 4, 2)]);
    }
}
