module sum_amounts::amounts {
    const E_NOT_IMPLEMENTED: u64 = 1;
    const E_DUPLICATE_ID: u64 = 2;

    public struct Obligation has copy, drop {
        public id: u64,
        public amount_due: u64,
        public priority: u64,
    }

    public struct Line has copy, drop {
        public id: u64,
        public applied: u64,
    }

    public struct Settlement has copy, drop {
        public lines: vector<Line>,
        public unapplied: u64,
    }

    public fun settle(_payment: u64, _obligations: vector<Obligation>): Settlement {
        abort E_NOT_IMPLEMENTED
    }
}
